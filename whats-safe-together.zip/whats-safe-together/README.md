# What's Safe Together?

A medication-safety companion (educational only — not medical advice).

## Run locally

```bash
npm install
npm run dev
```

Then open the URL Vite prints (usually http://localhost:5173).

## Build for production

```bash
npm run build
npm run preview
```

## Notes
- The main component lives in `src/App.jsx`.
- Icons come from `lucide-react`. Fonts (Inter, Playfair Display) load via Google Fonts inside the component, so no extra setup is needed.
- The hero photo is embedded in `src/App.jsx` as a base64 data URI, so there is nothing else to host.
- This app uses inline styles only — no Tailwind required.
